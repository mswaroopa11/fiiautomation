from behave import *

@when(u'user apply for TIC')
def step_impl(context):
    context.tic_page.is_tic_page_displayed()
    context.tic_page.apply_now()


@then(u'user should be displayed with application if already applied')
def step_impl(context):
    assert  context.tic_page.is_view_applications_displayed()
