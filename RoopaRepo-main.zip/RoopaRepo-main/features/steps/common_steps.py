from behave import *
from pages.dev.dev_home_page import HomePage as DevHomePage
from pages.dev.dev_group_page import GroupPage as DevGroupPage
from pages.dev.dev_profile_page import ProfilePage as DevProfilePage
from pages.dev.dev_financials_page import FinancialsPage as DevFinancialsPage
from pages.dev.dev_tic_page import TicPage as DevTicPage
from pages.prod.prod_home_page import HomePage as ProdHomePage
from pages.prod.prod_group_page import GroupPage as ProdGroupPage
from pages.prod.prod_profile_page import ProfilePage as ProdProfilePage
from pages.prod.prod_financials_page import FinancialsPage as ProdFinancialsPage
from pages.dev.mobile_dev_home_page import HomePage as MobileDevHomePage
from pages.dev.mobile_dev_group_page import GroupPage as MobileDevGroupPage
from pages.dev.mobile_dev_profile_page import ProfilePage as MobileDevProfilePage
from pages.dev.mobile_dev_financials_page import FinancialsPage as MobileDevFinancialsPage
from pages.prod.mobile_prod_home_page import HomePage as MobileProdHomePage
from pages.prod.mobile_prod_group_page import GroupPage as MobileProdGroupPage
from pages.prod.mobile_prod_profile_page import ProfilePage as MobileProdProfilePage
from pages.prod.mobile_prod_financials_page import FinancialsPage as MobileProdFinancialsPage
from utilities.configreader import ReadConfig
import time

@given('user lands on token url and sets cookie')
def step_impl(context):
    test_env = context.config.userdata.get("env", "develop")
    test_device = context.config.userdata.get("device", "web")
    url = ReadConfig.get_dev_url()
    domain = ReadConfig.get_dev_domain()
    auth_token = ReadConfig.get_dev_auth_token()
    refresh_token = ReadConfig.get_dev_refresh_token()
    
    if test_env == "prod":
        url = ReadConfig.get_prod_url()
        domain = ReadConfig.get_prod_domain()
        auth_token = ReadConfig.get_prod_auth_token()
        refresh_token = ReadConfig.get_prod_refresh_token()
    elif test_env == "qa":
        url = ReadConfig.get_prod_url()
        domain = ReadConfig.get_prod_domain()
        auth_token = ReadConfig.get_prod_auth_token()
        refresh_token = ReadConfig.get_prod_refresh_token()
    elif test_env == "develop_tic":
        url = ReadConfig.get_dev_tic_url()
        domain = ReadConfig.get_dev_tic_domain()
        auth_token = ReadConfig.get_dev_tic_auth_token()
        refresh_token = ReadConfig.get_dev_tic_refresh_token()
    elif test_env == "develop":
        pass
    else:
        print("Invalid environment is provided. Kindly provide the environment as develop, qa or prod")
    context.browser.get(url)
    context.browser.add_cookie({"domain":domain, "name": "auth._token.uptogether", "value": auth_token})
    context.browser.add_cookie({"domain":domain, "name": "refresh._token.uptogether", "value": refresh_token})
    context.browser.get(url)

    time.sleep(1)
    if test_device == "web":
        if test_env == "prod":
            context.home_page = ProdHomePage(context.browser, test_device)
            context.group_page = ProdGroupPage(context.browser, test_device)
            context.profile_page = ProdProfilePage(context.browser, test_device)
            context.financials_page = ProdFinancialsPage(context.browser, test_device)
        else:
            context.home_page = DevHomePage(context.browser, test_device)
            context.group_page = DevGroupPage(context.browser, test_device)
            context.profile_page = DevProfilePage(context.browser, test_device)
            context.financials_page = DevFinancialsPage(context.browser, test_device)
            context.tic_page = DevTicPage(context.browser, test_device)
        context.browser.maximize_window()
    else:
        if test_env == "prod":
            context.home_page = MobileProdHomePage(context.browser, test_device)
            context.group_page = MobileProdGroupPage(context.browser, test_device)
            context.profile_page = MobileProdProfilePage(context.browser, test_device)
            context.financials_page = MobileProdFinancialsPage(context.browser, test_device)
        else:
            context.home_page = MobileDevHomePage(context.browser, test_device)
            context.group_page = MobileDevGroupPage(context.browser, test_device)
            context.profile_page = MobileDevProfilePage(context.browser, test_device)
            context.financials_page = MobileDevFinancialsPage(context.browser, test_device)

@given('user closes the intercom banner')
def step_impl(context):
    context.home_page.close_intercom_banner()

