from behave import *

@then('user verify group home tile in home page')
def step_impl(context):
    assert context.home_page.is_group_home_title_displayed()

@then('user verify group navigation tile in home page')
def step_impl(context):
    assert context.home_page.is_group_navigation_tile_displayed()

@then('user verify group navigation menu in home page')
def step_impl(context):
    assert context.home_page.is_group_navigation_menu_displayed()
    
@when(u'user lands on group portal')
def step_impl(context):
    context.home_page.open_group_portal()

@given(u'user navigates to Financials Page')
def step_impl(context):
    context.home_page.open_financials_page()

@given(u'user navigates to Profile Page')
def step_impl(context):
    context.home_page.open_profile_page()