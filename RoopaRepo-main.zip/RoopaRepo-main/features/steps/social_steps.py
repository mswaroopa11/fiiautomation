from behave import *

@when(u'user creates a new group with group name as "{groupName}" and group purpose as "{purpose}"')
def step_impl(context, groupName, purpose):
    context.group_page.create_group()
    context.group_page.set_group_name_purpose(groupName, purpose)
    
@when(u'checkin schedule as "{schedule}" and group agreements as "{agreements}"')
def step_impl(context, schedule, agreements):
    context.group_page.set_group_schedule_agreements(schedule, agreements)

@when(u'sets the group image as "{color}" color')
def step_impl(context, color):
    context.group_page.set_group_profile_color(color)
    context.group_page.create_group_final()

@when(u'adds a group image from computer with name "{image_name}"')
def step_impl(context, image_name):
    context.group_page.set_group_profile_image(image_name)

@then(u'verify that Congratulations page is displayed')
def step_impl(context):
    assert context.group_page.is_group_success()

@when(u'visit group details page')
def step_impl(context):
    context.group_page.visit_group_details()

@then(u'verify group name, group purpose, agreements and schedule')
def step_impl(context):
    assert context.group_page.verify_group_name()
    assert context.group_page.verify_group_purpose()
    assert context.group_page.verify_group_schedule()
    assert context.group_page.verify_group_agreements()

@when(u'stores the group name')
def step_impl(context):
    context.group_name = context.group_page.get_group_name()

@when(u'user views the first group') 
def step_impl(context):
    context.group_page.view_group()

@when(u'user views the group with name "{group_name}"')
def step_impl(context, group_name):
    context.group_page.view_group(group_name)
    
@when(u'opens the settings page of group')
def step_impl(context):
    context.group_page.open_group_settings()

@when(u'user leaves the group')
def step_impl(context):
    context.group_page.leave_group()

@then(u'verify that left group is no more available')
def step_impl(context):
    assert context.group_page.verify_presence_of_deleted_group() == False

@when(u'visits group portal')
def step_impl(context):
    context.home_page.open_group_portal_from_left_menu()

@when(u'visit newly created Group')
def step_impl(context):
    context.group_page.view_group(context.group_name)

@when(u'create a new ask')
def step_impl(context):
    context.group_page.create_ask()

@when(u'create a new contribution')
def step_impl(context):
    context.group_page.create_contribution()

@when(u'create a new goal sharing')
def step_impl(context):
    context.group_page.create_goal_sharing()

@when(u'create a new connections')
def step_impl(context):
    context.group_page.create_connections()

@when(u'add a label "{label}"')
def step_impl(context, label):
    context.group_page.add_label(label)

@when(u'post title as "{post_title}"')
def step_impl(context, post_title):
    context.group_page.add_post_title(post_title)

@when(u'ask question as "{ask_question}"')
def step_impl(context, ask_question):
    context.group_page.add_ask_question(ask_question)

@when(u'contribution question as "{contribution_question}"')
def step_impl(context, contribution_question):
    context.group_page.add_contribution_question(contribution_question)

@when(u'goal sharing question1 as "{goal_sharing_question1}"')
def step_impl(context, goal_sharing_question1):
    context.group_page.add_goal_sharing_question1(goal_sharing_question1)

@when(u'goal sharing question2 as "{goal_sharing_question2}"')
def step_impl(context, goal_sharing_question2):
    context.group_page.add_goal_sharing_question2(goal_sharing_question2)

@when(u'connections question as "{connections_question}"')
def step_impl(context, connections_question):
    context.group_page.add_connections_question(connections_question)

@when(u'user creates post')
def step_impl(context):
    context.group_page.post()

# @then(u'verify that ask is successfully created')
# def step_impl(context):
#     assert context.group_page.verify_post_successful(), "Ask is not created successfully"

# @when(u'user views the created ask')
# def step_impl(context):
#     context.group_page.view_post()

@then(u'verify ask label, title and question')
def step_impl(context):
    assert context.group_page.verify_ask_label()
    assert context.group_page.verify_ask_title()
    assert context.group_page.verify_ask_question()

@then(u'verify contribution label, title and question')
def step_impl(context):
    assert context.group_page.verify_contribution_label()
    assert context.group_page.verify_contribution_title()
    assert context.group_page.verify_contribution_question()

@then(u'verify goal sharing label, title and question')
def step_impl(context):
    assert context.group_page.verify_goal_sharing_label()
    assert context.group_page.verify_goal_sharing_title()
    assert context.group_page.verify_goal_sharing_question()

@then(u'verify connections question')
def step_impl(context):
    assert context.group_page.verify_connections_question()

@when(u'user navigates to All Tab')
def step_impl(context):
    context.group_page.navigate_all_tab()

@when(u'edit the created ask post')
def step_impl(context):
    context.group_page.edit_ask_post()

@when(u'edit the created contribution post')
def step_impl(context):
    context.group_page.edit_contribution_post()

@when(u'edit the created goal sharing post')
def step_impl(context):
    context.group_page.edit_goal_sharing_post()

@when(u'edit the created connections post')
def step_impl(context):
    context.group_page.edit_connections_post()

@when(u'upadate the post')
def step_impl(context):
    context.group_page.update_post()

@then(u'verify that ask post is edited')
def step_impl(context):
    assert context.group_page.verify_ask_post_edited()

@then(u'verify that contribution post is edited')
def step_impl(context):
    assert context.group_page.verify_contribution_post_edited()

@then(u'verify that goal sharing post is edited')
def step_impl(context):
    assert context.group_page.verify_goal_sharing_post_edited()

@then(u'verify that connections post is edited')
def step_impl(context):
    assert context.group_page.verify_connections_post_edited()

@when(u'user deletes its own ask post')
def step_impl(context):
    context.group_page.delete_ask_post()

@when(u'user deletes its own contribution post')
def step_impl(context):
    context.group_page.delete_contribution_post()

@when(u'user deletes its own goal sharing post')
def step_impl(context):
    context.group_page.delete_goal_sharing_post()

@when(u'user deletes its own connections post')
def step_impl(context):
    context.group_page.delete_connections_post()

@then(u'verify that ask post is deleted')
def step_impl(context):
    assert context.group_page.verify_ask_post_deleted()

@then(u'verify that contribution post is deleted')
def step_impl(context):
    assert context.group_page.verify_contribution_post_deleted()

@then(u'verify that goal sharing post is deleted')
def step_impl(context):
    assert context.group_page.verify_goal_sharing_post_deleted()

@then(u'verify that connections post is deleted')
def step_impl(context):
    assert context.group_page.verify_connections_post_deleted()

@when(u'user add a comment as "{comment}"')
def step_impl(context, comment):
    context.group_page.add_comment(comment)

@then(u'verify that comment is added')
def step_impl(context):
    assert context.group_page.verify_comment_added()

@when(u'user edit comment as "{new_comment}"')
def step_impl(context, new_comment):
    context.group_page.edit_comment(new_comment)

@then(u'verify the comment is edited')
def step_impl(context):
    assert context.group_page.verify_comment_edited()

@when(u'user delete the above comment')
def step_impl(context):
    context.group_page.delete_comment()

@then(u'verify the comment is deleted')
def step_impl(context):
    assert context.group_page.verify_comment_deleted()

@then(u'verify that user can view all the added comments')
def step_impl(context):
    assert context.group_page.verify_all_comments()

@when(u'views all the members of the Group')
def step_impl(context):
    context.group_page.view_all_group_members()

@then(u'verify that "{username}" has added a picture to profile')
def step_impl(context, username):
    context.group_page.verify_custom_profile_picture(username)

@then(u'verify that "{username}" has default picture in profile')
def step_impl(context, username):
    context.group_page.verify_default_profile_picture(username)

@when(u'sets the group image as below direct picture')
def step_impl(context):
    name = context.table[0][0]
    link = context.table[0][1]
    context.group_page.add_photo_for_group()
    context.group_page.set_direct_picture(name, link)
    context.group_page.create_group_final()
    
@when(u'delete all groups except below groups')
def step_impl(context):
    table = context.table
    rows = context.table.rows
    heading = context.table.headings
    # print(heading)
    # print(rows)
    context.excludedGroupList = []
    for i in range(len(rows)):
        context.excludedGroupList.append(rows[i][0])
    # print(context.excludedGroupList)
    context.group_page.delete_all_groups_with_exclusions(context.excludedGroupList)
    

@then(u'verify that all groups except above mentioned groups are deleted')
def step_impl(context):
    assert context.group_page.verify_all_groups_deleted_with_exclusions(context.excludedGroupList)