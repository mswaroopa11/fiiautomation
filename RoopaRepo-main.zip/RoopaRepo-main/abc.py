my_dict = {}

my_dict['abc'] = "ABC"

print(my_dict['abc'])

print(my_dict.get('xyz'))
