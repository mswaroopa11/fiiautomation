from utilities.util import Locators
from utilities.util import Utils
from utilities.util import Data
from selenium.webdriver.support.ui import Select
import time

class GroupPage:
    create_a_group_xpath = "//h2[contains(text(),'groups')]/following-sibling::a[contains(text(),'Create a Group')]"
    start_your_group_xpath = "//div[contains(@class, 'tw-order-first')]//button[contains(text(),'Start your Group')]"
    group_name_txtbox_xpath = "//*[@id='id_group_name']"
    group_purpose_txtbox_xpath = "//*[@id='id_group_purpose']"
    next_xpath = "//button[contains(text(),'Next')]"
    check_in_schedule_xpath = "//*[@id='id_group_checkin_schedule']" # weekly, monthly or bimonthly
    group_agreements_txtbox_xpath = "//*[@id='id_group_agreements']"
    color_button_param_color_xpath = "//button[contains(@class,'COLOR')]" # green, blue, red, purple, gray
    add_group_pic_button = "//button[contains(text(), 'Add')]"
    create_xpath = "//button[contains(text(),'Create')]"
    group_creation_success_message_xpath = "//p[contains(text(),'Your Group is ready to go')]"
    group_success_xpath = "//h2[contains(text(), 'Congratulations')]"
    visit_group_xpath = "//button[contains(text(),'Visit Group')]"
    group_heading_xpath = "//h1[contains(text(),'GROUP_NAME')]"
    group_detail_xpath = "//a[contains(@href, 'members')][./span]"
    group_detail_back_xpath = "//span[@aria-label='Chevron Left icon']"
    group_purpose_xpath = "//h2[contains(text(),'Purpose')]/following-sibling::p"
    group_agreements_xpath = "//h2[contains(text(),'Agreements')]/following-sibling::p"
    schedule_xpath = "//span[@aria-label='Calendar icon']/parent::span"
    group_view_param_groupName_xpath = "//div[contains(text(),'View Group')][./preceding-sibling::div/div[contains(text(),'GROUP_NAME')]]"
    first_group_view_xpath = "(//div[contains(text(),'View Group')])[1]"
    first_group_name_xpath = "(//div[contains(text(),'View Group')])[1]/preceding-sibling::div/div[1]"
    view_group_param_seq_xpath = "(//div[contains(text(),'View Group')])[seq]"
    group_name_param_seq_xpath = "(//div[contains(text(),'View Group')])[seq]/preceding-sibling::div/div[1]"
    group_settings_xpath = "//a[contains(@href, 'settings')][contains(@href, 'groups')]"
    group_name_xpath = "//a[contains(@href, 'settings')]/following-sibling::h1"
    leave_group_xpath="//span[text()='Leave Group']"
    leave_group_confirmation_xpath = "//div[contains(text(),'Yes, leave this group')]"
    all_group_names_xpath = "//div[contains(text(),'View Group')]/preceding-sibling::div/div[1]"
    add_btn_xpath = "//button[contains(text(),'Add')]"
    local_files_xpath = "//div[@title='Local Files']"
    choose_a_local_file_xpath = "//button[contains(text(),'Choose a local file')]"
    ask_tab_xpath = "//a[contains(@href,'/ask')]"
    contribution_tab_xpath = "//a[contains(@href,'/contribution')]"
    goal_sharing_tab_xpath = "//a[contains(@href,'/goal')]"
    connections_tab_xpath = "//a[contains(@href,'/connection')]"
    back_btn_xpath = "//span[@aria-label='Chevron Left icon']"
    create_post_btn_xpath = "//a[contains(@href, '/create')]"
    label_btn_xpath = "//button[contains(text(), 'Label')]"
    label_btn_param_label_name_xpath = "//span[text()='LABEL_NAME']"
    ok_btn_xpath = "//button[contains(text(), 'OK')]"
    post_title_xpath = "//input[@placeholder='Title']"
    ask_question_xpath = "//div[@data-placeholder='What would you like to say?']/p"
    contribution_question_xpath = "//div[@data-placeholder='What would you like to say?']"
    goal_sharing_question1_xpath = "//div[@data-placeholder='What would you like to say?']"
    goal_sharing_question2_xpath = "//textarea[@placeholder='How can your group help you reach your goal?']"
    connections_question_xpath = "//div[@data-placeholder='What would you like to say?']"
    post_btn_xpath = "//p[contains(text(),'Post')]"
    post_successful_creation_label_xpath = "//p[contains(text(),'What are your thoughts')]"
    post_successful_msg_xpath = "//h2[contains(text(),'Your Post Was Successful')]"
    view_post_btn_xpath = "//button[contains(text(),'View Post')]"
    
    ask_label_param_title_label_xpath = "//header[contains(text(), 'Ask')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//span[text()='LABEL_NAME']"
    ask_title_param_title_xpath = "//header[contains(text(), 'Ask')]/following-sibling::article/h3[contains(text(), 'POST_TITLE')]"
    ask_question_param_title_question_xpath = "//header[contains(text(), 'Ask')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//p[contains(text(), 'ASK_QUESTION')]"
    ask_post_dropdown_param_title_xpath = "//header[contains(text(), 'Ask')]/following-sibling::article/h3[contains(text(), 'POST_TITLE')]/preceding-sibling::div//*[@class='hover:cursor-pointer']"
    
    contribution_label_param_title_label_xpath = "//header[contains(text(), 'Contribution')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//span[text()='LABEL_NAME']"
    contribution_title_param_title_xpath = "//header[contains(text(), 'Contribution')]/following-sibling::article/h3[contains(text(), 'POST_TITLE')]"
    contribution_question_param_title_question_xpath = "//header[contains(text(), 'Contribution')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//p[contains(text(), 'CONTRIBUTION_QUESTION')]"
    contribution_post_dropdown_param_title_xpath = "//header[contains(text(), 'Contribution')]/following-sibling::article/h3[contains(text(), 'POST_TITLE')]/preceding-sibling::div//*[@class='hover:cursor-pointer']"
    
    goal_sharing_label_param_title_label_xpath = "//header[contains(text(), 'Goal Sharing')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//span[text()='LABEL_NAME']"
    goal_sharing_title_param_title_xpath = "//header[contains(text(), 'Goal Sharing')]/following-sibling::article/h3[contains(text(), 'POST_TITLE')]"
    goal_sharing_question1_param_title_question_xpath = "//header[contains(text(), 'Goal Sharing')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//p[contains(text(), 'GOAL_SHARING_QUESTION1')]"
    goal_sharing_question2_param_title_question_xpath = "//header[contains(text(), 'Goal Sharing')]/following-sibling::article[./h3[contains(text(), 'POST_TITLE')]]//p[contains(text(), 'GOAL_SHARING_QUESTION2')]"
    goal_sharing_post_dropdown_param_title_xpath = "//header[contains(text(), 'Goal Sharing')]/following-sibling::article/h3[contains(text(), 'POST_TITLE')]/preceding-sibling::div//*[@class='hover:cursor-pointer']"
    
    connections_question_param_question_xpath = "//p[contains(text(), 'CONNECTIONS_QUESTION')]"
    connections_post_dropdown_param_question_xpath = "//div[@group-name]/div[contains(@class,'full')]//div[contains(text(),'CONNECTIONS_QUESTION')]/ancestor::div[2]/preceding-sibling::div//*[@class='hover:tw-cursor-pointer']"

    edit_post_xpath = "//div[contains(text(), 'Edit post')]"
    delete_post_xpath = "//div[contains(text(), 'Delete your post')]"
    update_post_xpath = "//p[contains(text(),'Post')]"
    delete_post_confirmation_xpath = "//div[contains(text(), 'Yes, Delete This Post')]"
    all_ask_titles_xpath = "//header[contains(text(), 'Ask')]/following-sibling::article/h3"
    all_contribution_titles_xpath = "//header[contains(text(), 'Contribution')]/following-sibling::article/h3"
    all_goal_sharing_titles_xpath = "//header[contains(text(), 'Goal Sharing')]/following-sibling::article/h3"
    all_connections_questions_xpath = "//div[@group-name]/div[contains(@class,'full')]//div[contains(@class,'placeholder')]"
    comment_textarea_xpath = "//textarea[@placeholder='Add a comment']"
    comment_submit_xpath = "//button[@type='submit']"
    commented_label_param_comment_name_xpath = "//p[text()='COMMENT_NAME']"
    comment_dropdown_parent_display_xpath = "//p[text()='COMMENT_NAME']/ancestor::div[contains(@class,'tw-text-gray-title')]//*[@class='tw-mx-auto']/parent::span";
    comment_dropdown_param_comment_name_xpath = "//p[text()='COMMENT_NAME']/ancestor::div[contains(@class,'tw-text-gray-title')]//*[@class='tw-mx-auto']"
    edit_comment_button_xpath = "//div[contains(text(),'Edit comment')]"
    delete_comment_button_xpath = "//div[contains(text(),'Delete comment')]"
    delete_comment_confirmation_button_xpath = "//div[contains(text(),'Yes, delete this comment')]"
    # all_comments_in_post_xpath = "//div[./article]/following-sibling::div//div[@class='tw-flex']"
    all_comments_in_post_xpath = "//div[@class='tw-flex']"
    all_profile_pic_xpath = "//h3[contains(text(), 'Admin')]/parent::*//img"
    view_all_members_xpath = "//a[contains(text(),'View All Members')]"
    profile_pic_param_username_xpath = "//span[contains(text(), 'USERNAME')]/parent::div/preceding-sibling::img"

    upload_all_sources_xpath = "//button[contains(@class,'uploadcare--file-source_all')]"
    direct_link_image_xpath = "//div[@title='Direct Link']"
    direct_link_textbox_class = "uploadcare--input"
    direct_link_upload_xpath = "//button[text()='Upload']"
    direct_link_preview_done_xpath = "//button[text()='Done'][contains(@class,'preview__done')]"

    loggedInuser = "testroopa"
    testgroupuser1 = "Swaroopa  Muralidhar"
    testgroupuser2 = "Swaroopa M"

    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.utils = Utils(driver, device)
        self.data = Data()
        
    def create_group(self):
        time.sleep(5)
        self.utils.wait_for_element(self.create_a_group_xpath, Locators.XPATH)
        self.utils.click(self.create_a_group_xpath, Locators.XPATH)
        self.utils.click(self.start_your_group_xpath, Locators.XPATH)
        
    def set_group_name_purpose(self, groupName, groupPurpose):
        self.groupPurpose = groupPurpose
        self.randomGroupName = self.data.get_random_string(groupName)
        self.utils.send_keys(self.group_name_txtbox_xpath, self.randomGroupName, Locators.XPATH)
        self.utils.send_keys(self.group_purpose_txtbox_xpath, self.groupPurpose, Locators.XPATH)
        self.utils.click(self.next_xpath, Locators.XPATH)
        
    def set_group_schedule_agreements(self, schedule, agreements):
        self.schedule = schedule
        self.agreements = agreements
        select_schedule = Select(self.driver.find_element_by_xpath(self.check_in_schedule_xpath))
        select_schedule.select_by_value(schedule.replace("-", ""))
        self.utils.send_keys(self.group_agreements_txtbox_xpath, self.agreements, Locators.XPATH)
        self.utils.click(self.next_xpath, Locators.XPATH)
        
    def set_group_profile_color(self, color):
        self.utils.click(self.color_button_param_color_xpath.replace("COLOR", color), Locators.XPATH)

    def create_group_final(self):
        self.utils.click(self.create_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.group_creation_success_message_xpath, Locators.XPATH)
        
    def set_group_profile_image(self, image_name):
        self.utils.click(self.add_btn_xpath, Locators.XPATH)
        # self.utils.click(self.local_files_xpath, Locators.XPATH)
        # self.utils.click(self.choose_a_local_file_xpath, Locators.XPATH)
        self.utils.upload_file(image_name, self.local_files_xpath, Locators.XPATH)
        # self.utils.send_keys()

    def is_group_success(self):
        return self.utils.is_displayed(self.group_success_xpath, Locators.XPATH)
    
    def visit_group_details(self):
        self.utils.click(self.visit_group_xpath, Locators.XPATH)

    def verify_group_name(self):
        return self.utils.is_displayed(self.group_heading_xpath.replace("GROUP_NAME", self.randomGroupName), Locators.XPATH)

    def get_group_name(self):
        return self.utils.get_text(self.group_name_xpath, Locators.XPATH)

    def verify_group_purpose(self):
        self.utils.click(self.group_detail_xpath, Locators.XPATH)
        actual_group_purpose = self.utils.get_text(self.group_purpose_xpath, Locators.XPATH)
        return self.groupPurpose == actual_group_purpose.strip()
    
    def verify_group_schedule(self):
        actual_schedule =  self.utils.get_text(self.schedule_xpath, Locators.XPATH)
        return self.schedule.replace("-", "").lower() == actual_schedule.strip().lower()
    
    def verify_group_agreements(self):
        actual_group_agreements = self.utils.get_text(self.group_agreements_xpath, Locators.XPATH)
        check_agreements = self.agreements == actual_group_agreements.strip()
        self.utils.click(self.group_detail_back_xpath, Locators.XPATH)
        return check_agreements
    
    def view_group(self, group_name='first_grp'):
        if group_name == 'first_grp':
            group_name = self.utils.get_text(self.first_group_name_xpath, Locators.XPATH).strip()
        self.group_name = group_name
        self.utils.wait_for_element(self.group_view_param_groupName_xpath.replace("GROUP_NAME", group_name), Locators.XPATH)
        self.utils.bring_to_top(self.group_view_param_groupName_xpath.replace("GROUP_NAME", group_name), Locators.XPATH)
        self.utils.click(self.group_view_param_groupName_xpath.replace("GROUP_NAME", group_name), Locators.XPATH)
        self.utils.scroll_to_top()
        return group_name
        
    def open_group_settings(self):
        self.utils.click(self.group_detail_xpath, Locators.XPATH)
        self.utils.click(self.group_settings_xpath, Locators.XPATH)
        
    def leave_group(self):
        self.utils.click(self.leave_group_xpath, Locators.XPATH)
        self.utils.click(self.leave_group_confirmation_xpath, Locators.XPATH)
        
    def verify_presence_of_deleted_group(self):
        self.utils.wait_for_element(self.first_group_view_xpath, Locators.XPATH)
        all_elements = self.driver.find_elements_by_xpath(self.all_group_names_xpath)
        all_group_names = []
        for element in all_elements:
            all_group_names.append(element.text.strip())
        for grp_name in all_group_names:
            if grp_name == self.group_name:
                return True
        return False

    def create_ask(self):
        self.utils.click(self.ask_tab_xpath, Locators.XPATH)
        self.utils.click(self.create_post_btn_xpath, Locators.XPATH)

    def create_contribution(self):
        self.utils.click(self.contribution_tab_xpath, Locators.XPATH)
        self.utils.click(self.create_post_btn_xpath, Locators.XPATH)

    def create_goal_sharing(self):
        self.utils.click(self.goal_sharing_tab_xpath, Locators.XPATH)
        self.utils.click(self.create_post_btn_xpath, Locators.XPATH)

    def create_connections(self):
        self.utils.click(self.connections_tab_xpath, Locators.XPATH)
        self.utils.click(self.create_post_btn_xpath, Locators.XPATH)

    def add_label(self, label_name):
        self.label_name = label_name
        self.utils.click(self.label_btn_xpath, Locators.XPATH)
        self.utils.click(self.label_btn_param_label_name_xpath.replace("LABEL_NAME", label_name), Locators.XPATH)
        self.utils.click(self.ok_btn_xpath, Locators.XPATH)

    def add_post_title(self, post_title):
        self.random_post_title = self.data.get_random_string(post_title)
        self.utils.send_keys(self.post_title_xpath, self.random_post_title, Locators.XPATH)

    def add_ask_question(self, ask_question):
        self.ask_question = ask_question
        self.utils.js_innerHTML(self.ask_question_xpath, self.ask_question, Locators.XPATH)

    def add_contribution_question(self, contribution_question):
        self.contribution_question = contribution_question
        self.utils.js_innerHTML(self.contribution_question_xpath, self.contribution_question, Locators.XPATH)

    def add_goal_sharing_question1(self, goal_sharing_question1):
        self.goal_sharing_question1 = goal_sharing_question1
        self.utils.js_innerHTML(self.goal_sharing_question1_xpath, self.goal_sharing_question1, Locators.XPATH)

    def add_goal_sharing_question2(self, goal_sharing_question2):
        self.goal_sharing_question2 = goal_sharing_question2
        self.utils.js_innerHTML(self.goal_sharing_question2_xpath, self.goal_sharing_question2, Locators.XPATH)

    def add_connections_question(self, connections_question):
        self.random_connections_question = self.data.get_random_string(connections_question)
        self.utils.js_innerHTML(self.connections_question_xpath, self.random_connections_question, Locators.XPATH)

    def post(self):
        self.utils.click(self.post_btn_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.post_successful_creation_label_xpath, Locators.XPATH)
        time.sleep(5)

    def verify_post_successful(self):
        return self.utils.is_displayed(self.post_successful_msg_xpath, Locators.XPATH)

    def view_post(self):
        self.utils.click(self.view_post_btn_xpath, Locators.XPATH)

    def verify_ask_label(self):
        return self.utils.is_displayed(self.ask_label_param_title_label_xpath.replace("POST_TITLE", self.random_post_title).replace("LABEL_NAME", self.label_name), Locators.XPATH)

    def verify_ask_title(self):
        return self.utils.is_displayed(self.ask_title_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)

    def verify_ask_question(self):
        return self.utils.is_displayed(self.ask_question_param_title_question_xpath.replace("POST_TITLE", self.random_post_title).replace("ASK_QUESTION", self.ask_question), Locators.XPATH)

    def verify_contribution_label(self):
        return self.utils.is_displayed(self.contribution_label_param_title_label_xpath.replace("POST_TITLE", self.random_post_title).replace("LABEL_NAME", self.label_name), Locators.XPATH)

    def verify_contribution_title(self):
        return self.utils.is_displayed(self.contribution_title_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)

    def verify_contribution_question(self):
        return self.utils.is_displayed(self.contribution_question_param_title_question_xpath.replace("POST_TITLE", self.random_post_title).replace("CONTRIBUTION_QUESTION", self.contribution_question), Locators.XPATH)

    def verify_goal_sharing_label(self):
        return self.utils.is_displayed(self.goal_sharing_label_param_title_label_xpath.replace("POST_TITLE", self.random_post_title).replace("LABEL_NAME", self.label_name), Locators.XPATH)

    def verify_goal_sharing_title(self):
        return self.utils.is_displayed(self.goal_sharing_title_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)

    def verify_goal_sharing_question(self):
        return self.utils.is_displayed(self.goal_sharing_question1_param_title_question_xpath.replace("POST_TITLE", self.random_post_title).replace("GOAL_SHARING_QUESTION1", self.goal_sharing_question1), Locators.XPATH)

    def verify_connections_label(self):
        return self.utils.is_displayed(self.connections_label_param_title_label_xpath.replace("POST_TITLE", self.random_post_title).replace("LABEL_NAME", self.label_name), Locators.XPATH)

    def verify_connections_title(self):
        return self.utils.is_displayed(self.connections_title_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)

    def verify_connections_question(self):
        return self.utils.is_displayed(self.connections_question_param_question_xpath.replace("CONNECTIONS_QUESTION", self.random_connections_question), Locators.XPATH)

    def navigate_all_tab(self):
        self.utils.click(self.back_btn_xpath, Locators.XPATH)
        self.utils.click(self.back_btn_xpath, Locators.XPATH)

    def edit_ask_post(self):
        self.utils.click(self.ask_post_dropdown_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)
        self.utils.click(self.edit_post_xpath, Locators.XPATH)
        self.previous_title = self.random_post_title

    def edit_contribution_post(self):
        self.utils.click(self.contribution_post_dropdown_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)
        self.utils.click(self.edit_post_xpath, Locators.XPATH)
        self.previous_title = self.random_post_title

    def edit_goal_sharing_post(self):
        self.utils.click(self.goal_sharing_post_dropdown_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)
        self.utils.click(self.edit_post_xpath, Locators.XPATH)
        self.previous_title = self.random_post_title

    def edit_connections_post(self):
        self.utils.click(self.connections_post_dropdown_param_question_xpath.replace("CONNECTIONS_QUESTION", self.random_connections_question), Locators.XPATH)
        self.utils.click(self.edit_post_xpath, Locators.XPATH)
        self.previous_question = self.random_connections_question

    def update_post(self):
        self.utils.click(self.update_post_xpath, Locators.XPATH)
        time.sleep(5)

    def verify_ask_post_edited(self):
        self.utils.click(self.back_btn_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.all_ask_titles_xpath, Locators.XPATH)
        all_elements = self.driver.find_elements_by_xpath(self.all_ask_titles_xpath)
        all_titles = []
        for element in all_elements:
            all_titles.append(element.text.strip())
        return self.random_post_title in all_titles and self.previous_title not in all_titles

    def verify_contribution_post_edited(self):
        self.utils.click(self.back_btn_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.all_contribution_titles_xpath, Locators.XPATH)
        all_elements = self.driver.find_elements_by_xpath(self.all_contribution_titles_xpath)
        all_titles = []
        for element in all_elements:
            all_titles.append(element.text.strip())
        return self.random_post_title in all_titles and self.previous_title not in all_titles

    def verify_goal_sharing_post_edited(self):
        self.utils.click(self.back_btn_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.all_goal_sharing_titles_xpath, Locators.XPATH)
        all_elements = self.driver.find_elements_by_xpath(self.all_goal_sharing_titles_xpath)
        all_titles = []
        for element in all_elements:
            all_titles.append(element.text.strip())
        return self.random_post_title in all_titles and self.previous_title not in all_titles

    def verify_connections_post_edited(self):
        self.utils.click(self.back_btn_xpath, Locators.XPATH)
        self.utils.click(self.back_btn_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.all_connections_questions_xpath, Locators.XPATH)
        all_elements = self.driver.find_elements_by_xpath(self.all_connections_questions_xpath)
        all_questions = []
        for element in all_elements:
            all_questions.append(element.text.strip())
        return self.random_connections_question in all_questions and self.previous_question not in all_questions

    def delete_ask_post(self):
        self.utils.click(self.ask_post_dropdown_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)
        self.utils.click(self.delete_post_xpath, Locators.XPATH)
        self.utils.click(self.delete_post_confirmation_xpath, Locators.XPATH)

    def delete_contribution_post(self):
        self.utils.click(self.contribution_post_dropdown_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)
        self.utils.click(self.delete_post_xpath, Locators.XPATH)
        self.utils.click(self.delete_post_confirmation_xpath, Locators.XPATH)

    def delete_goal_sharing_post(self):
        self.utils.click(self.goal_sharing_post_dropdown_param_title_xpath.replace("POST_TITLE", self.random_post_title), Locators.XPATH)
        self.utils.click(self.delete_post_xpath, Locators.XPATH)
        self.utils.click(self.delete_post_confirmation_xpath, Locators.XPATH)

    def delete_connections_post(self):
        self.utils.click(self.connections_post_dropdown_param_question_xpath.replace("CONNECTIONS_QUESTION", self.random_connections_question), Locators.XPATH)
        self.utils.click(self.delete_post_xpath, Locators.XPATH)
        self.utils.click(self.delete_post_confirmation_xpath, Locators.XPATH)

    def verify_ask_post_deleted(self):
        self.utils.click(self.ask_tab_xpath, Locators.XPATH)
        is_post_present = self.utils.is_element_present(self.all_ask_titles_xpath, Locators.XPATH)
        if is_post_present == True:
            all_elements = self.driver.find_elements_by_xpath(self.all_ask_titles_xpath)
            all_titles = []
            for element in all_elements:
                all_titles.append(element.text.strip())
            return self.random_post_title not in all_titles
        else:
            return True

    def verify_contribution_post_deleted(self):
        self.utils.click(self.contribution_tab_xpath, Locators.XPATH)
        is_post_present = self.utils.is_element_present(self.all_contribution_titles_xpath, Locators.XPATH)
        if is_post_present == True:
            all_elements = self.driver.find_elements_by_xpath(self.all_contribution_titles_xpath)
            all_titles = []
            for element in all_elements:
                all_titles.append(element.text.strip())
            return self.random_post_title not in all_titles
        else:
            return True

    def verify_goal_sharing_post_deleted(self):
        self.utils.click(self.goal_sharing_tab_xpath, Locators.XPATH)
        is_post_present = self.utils.is_element_present(self.all_goal_sharing_titles_xpath, Locators.XPATH)
        if is_post_present == True:
            all_elements = self.driver.find_elements_by_xpath(self.all_goal_sharing_titles_xpath)
            all_titles = []
            for element in all_elements:
                all_titles.append(element.text.strip())
            return self.random_post_title not in all_titles
        else:
            return True

    def verify_connections_post_deleted(self):
        self.utils.click(self.connections_tab_xpath, Locators.XPATH)
        is_post_present = self.utils.is_element_present(self.all_connections_questions_xpath, Locators.XPATH)
        if is_post_present == True:
            all_elements = self.driver.find_elements_by_xpath(self.all_connections_questions_xpath)
            all_questions = []
            for element in all_elements:
                all_questions.append(element.text.strip())
            return self.random_connections_question not in all_questions
        else:
            return True
            
    def add_comment(self, comment_name):
        if hasattr(self, 'comment_count'):
            self.comment_count = self.comment_count + 1
        else:
            self.comment_count = 1
        self.comment_name = comment_name
        self.utils.wait_for_element(self.comment_textarea_xpath, Locators.XPATH)
        self.utils.send_keys(self.comment_textarea_xpath, comment_name, Locators.XPATH)
        self.utils.click(self.comment_submit_xpath, Locators.XPATH)
        time.sleep(2)

    def verify_comment_added(self):
        actual_comment = self.utils.get_text(self.commented_label_param_comment_name_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH) 
        return self.comment_name == actual_comment

    def edit_comment(self, new_comment_name):
        self.utils.js_flex_display(self.comment_dropdown_parent_display_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH)
        self.utils.click(self.comment_dropdown_param_comment_name_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH)
        self.utils.click(self.edit_comment_button_xpath, Locators.XPATH)
        self.utils.send_keys(self.comment_textarea_xpath, new_comment_name, Locators.XPATH)
        self.utils.click(self.comment_submit_xpath, Locators.XPATH)
        self.old_comment_name = self.comment_name
        self.comment_name = new_comment_name

    def verify_comment_edited(self):
        actual_comment = self.utils.get_text(self.commented_label_param_comment_name_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH) 
        return self.comment_name == actual_comment and self.old_comment_name != actual_comment

    def delete_comment(self):
        self.utils.js_flex_display(self.comment_dropdown_parent_display_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH)
        self.utils.click(self.comment_dropdown_param_comment_name_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH)
        self.utils.click(self.delete_comment_button_xpath, Locators.XPATH)
        self.utils.click(self.delete_comment_confirmation_button_xpath, Locators.XPATH)

    def verify_comment_deleted(self):
        return False == self.utils.is_element_present(self.comment_dropdown_param_comment_name_xpath.replace("COMMENT_NAME", self.comment_name), Locators.XPATH)

    def verify_all_comments(self):
        all_elements = self.driver.find_elements_by_xpath(self.all_comments_in_post_xpath)
        return self.comment_count == len(all_elements)

    def view_all_group_members(self):
        self.utils.click(self.group_detail_xpath, Locators.XPATH)
        self.utils.click(self.view_all_members_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.all_profile_pic_xpath, Locators.XPATH)

    def verify_custom_profile_picture(self, username):
        if username == "loggedInuser":
            username = self.loggedInuser
        elif username == "testgroupuser1":
            username = self.testgroupuser1
        elif username == "testgroupuser2":
            username = self.testgroupuser2
        src_name = self.driver.find_element_by_xpath(self.profile_pic_param_username_xpath.replace("USERNAME", username)).get_attribute("src")
        return "default" not in src_name

    def verify_default_profile_picture(self, username):
        if username == "loggedInuser":
            username = self.loggedInuser
        elif username == "testgroupuser1":
            username = self.testgroupuser1
        elif username == "testgroupuser2":
            username = self.testgroupuser2
        src_name = self.driver.find_element_by_xpath(self.profile_pic_param_username_xpath.replace("USERNAME", username)).get_attribute("src")
        return "default" in src_name

    def add_photo_for_group(self):
        self.utils.click(self.add_group_pic_button, Locators.XPATH)

    def set_direct_picture(self, name, link):
        self.utils.click(self.upload_all_sources_xpath, Locators.XPATH)
        self.utils.click(self.direct_link_image_xpath, Locators.XPATH)
        self.utils.js_send_keys(self.direct_link_textbox_class, link, Locators.CLASS_NAME)
        self.utils.js_enable_button(self.direct_link_upload_xpath, Locators.XPATH)
        self.utils.js_click(self.direct_link_upload_xpath, Locators.XPATH)
        time.sleep(8)
        self.utils.click(self.direct_link_preview_done_xpath, Locators.XPATH)

    def get_group_name_with_seq(self, seq):
        return self.utils.get_text(self.group_name_param_seq_xpath.replace('seq', seq), Locators.XPATH)

    def view_group_with_seq(self, seq):
        self.utils.bring_to_top(self.view_group_param_seq_xpath.replace("seq", seq), Locators.XPATH)
        self.utils.click(self.view_group_param_seq_xpath.replace("seq", seq), Locators.XPATH)

    def delete_all_groups_with_exclusions(self, excludedGroupList):
        group_seq = 1
        while True:          
            self.utils.wait_for_element(self.first_group_view_xpath, Locators.XPATH)
            if self.utils.is_element_present(self.group_name_param_seq_xpath.replace('seq', str(group_seq)), Locators.XPATH):
                group_name = self.get_group_name_with_seq(str(group_seq))
                if group_name in excludedGroupList:
                    print('Group skipped from deletion - ', group_name)
                    group_seq = group_seq + 1
                    continue
                else:
                    self.view_group_with_seq(str(group_seq))
                    self.open_group_settings()
                    self.leave_group()
                    print('Group Deleted - ', group_name)               
            else:
                break

    def verify_all_groups_deleted_with_exclusions(self, excludedGroupList):
        is_matching = True
        all_elements = self.driver.find_elements_by_xpath(self.all_group_names_xpath)
        all_group_names = []
        for element in all_elements:
            all_group_names.append(element.text.strip())
        if len(all_group_names) == len(excludedGroupList):
            for item in all_group_names:
                if item not in excludedGroupList:
                    is_matching = False
                    break
        else:
            is_matching = False
        return is_matching  
