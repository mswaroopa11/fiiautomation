from utilities.util import Locators
from utilities.util import Utils
import time

class HomePage:
    group_home_tile_xpath = "//img[contains(@src,'groups')]"
    explore_groups_xpath = "//span[text()='Explore Groups']"
    top_menu_xpath = "//div[contains(@class,'tw-flex-grow')]/div[contains(@class,'nav-toggle')]"
    home_navigation_tile_xpath = "//div[contains(@class,'navigation-links')]/a[1]"
    group_navigation_menu_xpath = "//span[contains(@class,'navigation-title')][text()='Groups']"
    financials_navigation_menu_xpath = "//span[contains(@class,'navigation-title')][text()='Financials']"
    settings_navigation_menu_xpath = "//span[contains(@class,'navigation-title')][text()='Settings']"
    profile_submenu_xpath = "//span[text()='Profile']"
    home_navigation_menu_xpath = "//span[contains(@class,'navigation-title')][text()='Home']"
    group_right_arrow_xpath = "//a[contains(@href,'groups')]//span[@aria-label='Arrow Right icon']"
    first_group_view_xpath = "(//div[contains(text(),'View Group')])[1]"
    frame_intercombanner_name = "intercom-banner-frame"
    intercombanner_close = "//div[@aria-label='Close']"
    profile_header_xpath = "//span[text()='Profile']"
    financials_header_xpath = "//div[@class='title'][text()='Financials']"
    
    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.utils = Utils(driver, device)
        
    def is_group_home_title_displayed(self):
        self.utils.wait_for_element(self.group_home_tile_xpath, Locators.XPATH)
        return self.utils.is_displayed(self.group_home_tile_xpath, Locators.XPATH)
    
    def is_group_navigation_tile_displayed(self):
        return self.utils.is_displayed(self.explore_groups_xpath, Locators.XPATH)
    
    def is_group_navigation_menu_displayed(self):
        self.utils.click(self.top_menu_xpath, Locators.XPATH)
        return self.utils.is_displayed(self.group_navigation_menu_xpath, Locators.XPATH)
    
    def open_group_portal(self):
        self.utils.click(self.explore_groups_xpath, Locators.XPATH)

    def open_group_portal_from_left_menu(self):
        self.utils.wait_for_element(self.top_menu_xpath, Locators.XPATH)
        self.utils.click(self.top_menu_xpath, Locators.XPATH)
        self.utils.click(self.group_navigation_menu_xpath, Locators.XPATH)

    def close_intercom_banner(self):
        try:
            self.utils.wait_for_element(self.frame_intercombanner_name, Locators.NAME, 40)
            bannerframes = self.driver.find_elements_by_name(self.frame_intercombanner_name)
            if len(bannerframes) > 0:
                self.driver.switch_to.frame(self.frame_intercombanner_name)
                self.driver.find_element_by_xpath(self.intercombanner_close).click()
                self.driver.switch_to.default_content()
                time.sleep(1)
        except:
            print('Banner intercom is not displayed')
        
    def open_profile_page(self):
        self.utils.wait_for_element(self.top_menu_xpath, Locators.XPATH)
        self.utils.click(self.top_menu_xpath, Locators.XPATH)
        self.utils.click(self.settings_navigation_menu_xpath, Locators.XPATH)
        self.utils.click(self.profile_submenu_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.profile_header_xpath, Locators.XPATH)

    def open_financials_page(self):
        self.utils.wait_for_element(self.top_menu_xpath, Locators.XPATH)
        self.utils.click(self.top_menu_xpath, Locators.XPATH)
        self.utils.click(self.financials_navigation_menu_xpath, Locators.XPATH)
        self.utils.wait_for_element(self.financials_header_xpath, Locators.XPATH)