from utilities.util import Locators
from utilities.util import Utils
from utilities.util import Data
import time


class ProfilePage:
    profile_header_xpath = "//span[text()='Profile']"
    basic_infomation_xpath = "//a[contains(@href,'/settings/profile/basic')]"
    basic_information_header_xpath = "//a[contains(@href,'/settings/profile/basic')]/span"
    language_setting_ddown_xpath = "//select[contains(@id, 'language_preference')]"
    save_button_xpath = "//button[contains(text(), 'save')] | //button[contains(text(), 'guardar')]"
    profile_updated_header_xpath = "//p[text()='Profile Updated']"
    ok_button_xpath = "//button[contains(text(), 'Ok')]"
    first_name_xpath = "//input[contains(@id,'first_name')]"
    last_name_xpath = "//input[contains(@id,'last_name')]"
    gender_ddown_xpath = "//select[contains(@id,'gender')]"
    date_of_birth_xpath = "//input[contains(@id,'dob')]"
    ethnicity_xpath = "//input[contains(@id,'ethnicity')]"
    all_races_xpath = "//label[contains(@for,'race')]/following-sibling::div/label"
    household_infomation_xpath = "//a[contains(@href,'/settings/profile/household')]"
    household_members_xpath = "//h3[contains(text(), 'household members')]/following-sibling::div/a[contains(@href,'household')]"
    household_member_names_xpath = "//h3[contains(text(), 'household members')]/following-sibling::div/a[contains(@href,'household')]/div[1]"
    add_member_button_xpath = "//a[contains(@href,'/household/create')]"
    first_name_id = "id_firstName"
    last_name_id = "id_lastName"
    relationship_ddown_id = "id_relationshipType"
    dob_id = "id_dob"
    household_member_param_fname_xpath = "//a[contains(@href,'/household')]/div[contains(text(), 'FNAME')]"
    delete_button_xpath = "//button[contains(text(), 'delete')]"
    delete_conformation_button_xpath = "//button[contains(text(), 'Yes, Delete Member')]"
    delete_household_success_message_xpath = "//p[text()='Household member has been removed!']"
    close_button_xpath = "//button[text()='Close']"
    edit_household_success_message_xpath = "//p[text()='Household member information saved successfully!']"
    contact_information_xpath = "//a[contains(@href,'/settings/profile/contact')]"
    add_new_email_xpath = "//button[contains(text(), 'Add New Email')]"
    email_address_id = "id_Email Address"
    send_button_xpath = "//p[text()='Send']"
    email_code_id = "id_Code"
    verify_code_xpath = "//p[text()='Verify Code']"
    secondary_email_address = "//p[contains(text(),'Email Address #')]/ancestor::div[2]/following-sibling::p"
    primary_email_address = "//p[contains(text(),'Primary Email Address')]/ancestor::div[2]/following-sibling::p"
    temp_email_loading = "//input[@id='mail'][contains(@class,'disabledText')]"
    temp_email_id = "mail"
    refresh_button_id = "click-to-refresh"
    last_email_div_xpath = "//div[@class='inbox-dataList']//li[last()]"
    email_code_message_xpath = "//p[text()='Greetings,']/following-sibling::p[2]"
    delete_email_button_xpath = "//button[text()='Delete']"
    add_new_mobile_phone_xpath = "//button[contains(text(), 'Add New Mobile Phone')]"
    address_xpath = "//a[contains(@href,'/settings/profile/address')]"
    add_address_xpath = "//a[contains(@href,'/settings/profile/address/create')]"
    address1_id = "address_address1"
    address2_id = "address_address2"
    city_id = "address_city"
    state_id = "address_state"
    zip_id = "address_zip"
    last_address_xpath = "//div[@test-id='address'][last()]"
    all_address_xpath = "//div[@test-id='address']"
    address_param_address_xpath = "//div[@test-id='address'][./div[contains(text(),'ADDRESS')]]"
    primary_home_last_address_mark_xpath = "//div[@test-id='address'][last()]//span[contains(@class,'tw-visible')]"
    primary_home_address_mark_param_address_xpath = "//div[@test-id='address'][./div[contains(text(),'ADDRESS')]]//span[contains(@class,'tw-visible')]"
    address_menu_param_address_xpath = "//div[@test-id='address'][./div[contains(text(),'ADDRESS')]]//div[@class='dropdown-trigger']"
    other_address_menu_param_address_xpath = "//div[@test-id='address'][not(./div[contains(text(),'ADDRESS')])]//div[@class='dropdown-trigger']"
    last_address_menu_xpath = "//div[@test-id='address'][last()]//div[@class='dropdown-trigger']"
    delete_address_xpath = "//a[contains(text(),'Delete Address')][not(.//ancestor::div[(contains(@style,'none'))])]"
    delete_address_confirmation_xpath = "//button[contains(text(),'Yes, delete')]"
    edit_address_xpath = "//a[contains(text(),'Edit Address')][not(.//ancestor::div[(contains(@style,'none'))])]"
    make_primary_home_address_xpath = "//a[contains(text(),'Make Primary')][not(.//ancestor::div[(contains(@style,'none'))])]"
    edit_address_prompt_accept = "//button[text()='I Understand']"
    lose_money_prompt_accept = "//button[text()='Cancel']/following-sibling::button"

    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.utils = Utils(driver, device)
        self.data = Data()

    def is_profile_page_displayed(self):
        self.utils.wait_for_element(self.profile_header_xpath, Locators.XPATH)
        return self.utils.is_displayed(self.profile_header_xpath, Locators.XPATH)

    def open_basic_information(self):
        self.utils.click(self.basic_infomation_xpath, Locators.XPATH)

    def set_language(self, language_name):
        self.utils.set_dropdown_by_value(self.language_setting_ddown_xpath, language_name, Locators.XPATH, 2)

    def save_page(self):
        self.utils.click(self.save_button_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def confirm_profile_updated(self):
        self.utils.wait_for_element(self.profile_updated_header_xpath, Locators.XPATH)
        self.utils.click(self.ok_button_xpath, Locators.XPATH)

    def get_information_basic_header_name(self):
        return self.utils.get_text(self.basic_information_header_xpath, Locators.XPATH)

    def get_first_name(self):
        return self.utils.get_attribute(self.first_name_xpath, Locators.XPATH, "value")

    def set_first_name(self, first_name):
        self.utils.send_keys(self.first_name_xpath, first_name, Locators.XPATH)

    def get_last_name(self):
        return self.utils.get_attribute(self.last_name_xpath, Locators.XPATH, "value")

    def set_last_name(self, last_name):
        self.utils.send_keys(self.last_name_xpath, last_name, Locators.XPATH)

    def get_gender(self):
        return self.utils.get_dropdown_selected_value(self.gender_ddown_xpath, Locators.XPATH)

    def set_gender(self, gender):
        self.utils.set_dropdown_by_value(self.gender_ddown_xpath, gender, Locators.XPATH, 2)

    def get_date_of_birth(self):
        return self.utils.get_attribute(self.date_of_birth_xpath, Locators.XPATH, "value")

    def set_date_of_birth(self, date_of_birth):
        self.utils.send_keys(self.date_of_birth_xpath, date_of_birth, Locators.XPATH)

    def get_ethnicity(self):
        return self.utils.get_attribute(self.ethnicity_xpath, Locators.XPATH, "value")

    def set_ethnicity(self, ethnicity):
        self.utils.send_keys(self.ethnicity_xpath, ethnicity, Locators.XPATH)

    def get_race(self):
        return self.utils.get_checkbox_selected_value(self.all_races_xpath, Locators.XPATH)

    def set_race(self, race):
        self.utils.set_checkbox_by_value(self.all_races_xpath, race, Locators.XPATH)

    def open_household_information(self):
        self.utils.click(self.household_infomation_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def get_household_members(self):
        return len(self.utils.find_elements(self.household_members_xpath, Locators.XPATH))

    def get_household_member_first_names(self):
        all_names_ele = self.utils.find_elements(self.household_member_names_xpath, Locators.XPATH)
        all_first_names = []
        for name_ele in all_names_ele:
            full_name = name_ele.text.strip()
            all_first_names.append(full_name.split(" ")[0])
        return all_first_names

    def add_household_member(self):
        self.utils.click(self.add_member_button_xpath, Locators.XPATH)

    def set_household_first_name(self, fname):
        self.utils.send_keys(self.first_name_id, self.data.set_unique_name(fname), Locators.ID)

    def set_household_last_name(self, lname):
        self.utils.send_keys(self.last_name_id, self.data.set_unique_name(lname), Locators.ID)

    def set_household_relationship(self, relationship):
        self.utils.set_dropdown_by_value(self.relationship_ddown_id, relationship, Locators.ID)

    def set_household_dob(self, dob):
        self.utils.send_keys(self.dob_id, dob, Locators.ID)

    def check_presence_of_household_fname(self, fname):
        unique_fname = self.data.get_unique_name(fname)
        all_fnames = self.get_household_member_first_names()
        return unique_fname in all_fnames

    def open_household_member_with_fname(self, fname):
        self.utils.click(self.household_member_param_fname_xpath.replace("FNAME", self.data.get_unique_name(fname)),
                         Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def delete_household_member(self):
        self.utils.click(self.delete_button_xpath, Locators.XPATH)

    def delete_confirmation_household_member(self):
        self.utils.click(self.delete_conformation_button_xpath, Locators.XPATH)

    def check_delete_household_confirmation_message(self):
        return self.utils.is_displayed(self.delete_household_success_message_xpath, Locators.XPATH)

    def close_confirmation_message(self):
        self.utils.click(self.close_button_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def check_edit_household_confirmation_message(self):
        return self.utils.is_displayed(self.edit_household_success_message_xpath, Locators.XPATH)

    def verify_first_name_of_household(self, fname):
        assert self.data.get_unique_name(fname) == self.utils.get_attribute(self.first_name_id, Locators.ID, "value")

    def verify_last_name_of_household(self, lname):
        assert self.data.get_unique_name(lname) == self.utils.get_attribute(self.last_name_id, Locators.ID, "value")

    def verify_relationship_of_household(self, relationship):
        assert relationship == self.utils.get_dropdown_selected_value(self.relationship_ddown_id, Locators.ID)

    def verify_dob_of_household(self, dob):
        assert dob == self.utils.get_attribute(self.dob_id, Locators.ID, "value")

    def open_contact_information(self):
        self.utils.click(self.contact_information_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def add_new_email(self):
        self.utils.click(self.add_new_email_xpath, Locators.XPATH)

    def add_new_phone_number(self):
        self.utils.click(self.add_new_mobile_phone_xpath, Locators.XPATH)

    def fetch_a_temp_email(self):
        self.utils.open_new_tab_and_set_focus("https://temp-mail.org/en/")
        self.utils.wait_till_disappear(self.temp_email_loading, Locators.XPATH)
        self.temp_email_id = self.utils.get_attribute(self.temp_email_id, Locators.ID, "value")
        print(self.temp_email_id)
        self.utils.switch_to_other_window()

    def set_temp_email_address(self):
        self.utils.send_keys(self.email_address_id, self.temp_email_id, Locators.ID)

    def send_for_code(self):
        self.utils.click(self.send_button_xpath, Locators.XPATH)

    def fetch_email_code(self):
        self.utils.switch_to_other_window()
        self.utils.click(self.refresh_button_id, Locators.ID)
        self.utils.wait_till_disappear(self.temp_email_loading, Locators.XPATH)
        self.utils.bring_to_top(self.last_email_div_xpath, Locators.XPATH)
        self.utils.click(self.last_email_div_xpath, Locators.XPATH)
        code_msg = self.utils.get_text(self.email_code_message_xpath, Locators.XPATH)
        print(code_msg)
        self.email_code = code_msg.split(".")[0].split("is ")[1]
        print(self.email_code)
        self.utils.click(self.delete_email_button_xpath, Locators.XPATH)
        self.utils.switch_to_other_window()
        time.sleep(10)
        # last_email_div
        # all_emails_ele = self.utils.find_elements(self.all_email_div, Locators.XPATH)
        # all_first_names = []
        # for name_ele in range(len(all_names_ele)):
        #     full_name = name_ele.text.strip()
        #     all_first_names.append(full_name.split(" ")[0])
        # return all_first_names

    def open_address(self):
        self.utils.click(self.address_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def add_address(self):
        self.utils.click(self.add_address_xpath, Locators.XPATH)

    def add_address1(self, address1):
        self.address1 = address1
        self.utils.send_keys(self.address1_id, address1, Locators.ID)

    def add_address2(self, address2):
        self.address2 = address2
        self.utils.send_keys(self.address2_id, address2, Locators.ID)

    def add_city(self, city):
        self.city = city
        self.utils.send_keys(self.city_id, city, Locators.ID)

    def add_state(self, state):
        self.utils.set_dropdown_by_value(self.state_id, state, Locators.ID)
        self.state = self.utils.get_attribute(self.state_id, Locators.ID, 'value')

    def add_zip(self, zip):
        self.zip = zip
        self.utils.send_keys(self.zip_id, zip, Locators.ID)

    def verify_recently_added_address(self):
        address = self.utils.get_text(self.last_address_xpath, Locators.XPATH)
        assert self.address1 in address
        if hasattr(self, 'address2'):
            assert self.address2 in address
        assert self.city in address
        assert self.state in address
        assert self.zip in address

    def verify_address_added(self, add1):
        address = self.utils.get_text(self.address_param_address_xpath.replace('ADDRESS', add1), Locators.XPATH)
        assert self.address1 in address
        if hasattr(self, 'address2'):
            assert self.address2 in address
        assert self.city in address
        assert self.state in address
        assert self.zip in address

    def verify_address_primary_status(self):
        address_count = len(self.utils.find_elements(self.all_address_xpath, Locators.XPATH))
        is_present = self.utils.is_element_present(self.primary_home_last_address_mark_xpath, Locators.XPATH, 20)
        if address_count > 1:
            assert not is_present
        else:
            assert is_present

    def delete_last_address(self):
        self.utils.click(self.last_address_menu_xpath, Locators.XPATH)
        self.utils.click(self.delete_address_xpath, Locators.XPATH)
        self.utils.click(self.delete_address_confirmation_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def verify_recently_added_address_deleted(self):
        assert not (self.utils.is_element_present(self.address_param_address_xpath.replace('ADDRESS', self.address1),
                                                  Locators.XPATH, 20))

    def edit_last_address(self):
        self.utils.click(self.last_address_menu_xpath, Locators.XPATH)
        self.utils.click(self.edit_address_xpath, Locators.XPATH)

    def delete_address(self, add1):
        self.utils.click(self.address_menu_param_address_xpath.replace('ADDRESS', add1), Locators.XPATH)
        self.utils.click(self.delete_address_xpath, Locators.XPATH)
        self.utils.click(self.delete_address_confirmation_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def verify_address_deleted(self, add1):
        assert not (
            self.utils.is_element_present(self.address_param_address_xpath.replace('ADDRESS', add1), Locators.XPATH, 20))

    def set_address_as_primary(self, add1):
        self.utils.click(self.address_menu_param_address_xpath.replace('ADDRESS', add1), Locators.XPATH)
        self.utils.click(self.make_primary_home_address_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def verify_address_primary(self, add1):
        assert self.utils.is_element_present(self.primary_home_address_mark_param_address_xpath.replace('ADDRESS', add1), Locators.XPATH, 20)

    def set_other_address_as_primary(self, add1):
        self.utils.click(self.other_address_menu_param_address_xpath.replace('ADDRESS', add1), Locators.XPATH)
        self.utils.click(self.make_primary_home_address_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def accept_edit_address_prompt(self):
        if self.utils.is_element_present(self.edit_address_prompt_accept,Locators.XPATH, 20):
            self.utils.click(self.edit_address_prompt_accept, Locators.XPATH)
            self.utils.click(self.lose_money_prompt_accept, Locators.XPATH)
            self.utils.click(self.lose_money_prompt_accept, Locators.XPATH)

